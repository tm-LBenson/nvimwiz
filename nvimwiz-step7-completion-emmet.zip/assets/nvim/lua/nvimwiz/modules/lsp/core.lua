local M = {}

local function has_config(configs, name)
  return configs and configs[name] ~= nil
end

local function add_one(configs, servers, name, opts)
  if not has_config(configs, name) then
    return false
  end
  table.insert(servers, name)
  if opts then
    local cur = configs[name].default_config or {}
    configs[name].default_config = vim.tbl_deep_extend("force", cur, opts)
  end
  return true
end

local function add_prefer(configs, servers, preferred, fallback, opts)
  if add_one(configs, servers, preferred, opts) then
    return preferred
  end
  if fallback and add_one(configs, servers, fallback, opts) then
    return fallback
  end
  return nil
end

function M.spec()
  return {
    {
      "neovim/nvim-lspconfig",
      dependencies = { "williamboman/mason.nvim", "williamboman/mason-lspconfig.nvim" },
      config = function()
        local cfg = require("nvimwiz.generated.config")
        local wants = (cfg and cfg.lsp) or {}

        require("mason").setup({})
        local mlsp = require("mason-lspconfig")
        local lspconfig = require("lspconfig")
        local caps = require("nvimwiz.lsp").capabilities()

        local configs = lspconfig.configs
        local servers = {}

        if wants.typescript then
          add_prefer(configs, servers, "ts_ls", "tsserver")
        end
        if wants.python then
          add_one(configs, servers, "pyright")
        end
        if wants.web then
          add_one(configs, servers, "html")
          add_one(configs, servers, "cssls")
        end
        if wants.emmet then
          add_prefer(configs, servers, "emmet_ls", "emmet_language_server", {
            filetypes = {
              "html",
              "css",
              "scss",
              "less",
              "javascript",
              "javascriptreact",
              "typescript",
              "typescriptreact",
              "svelte",
              "vue",
            },
          })
        end
        if wants.go then
          add_one(configs, servers, "gopls")
        end
        if wants.bash then
          add_one(configs, servers, "bashls")
        end
        if wants.lua then
          add_one(configs, servers, "lua_ls", {
            settings = {
              Lua = {
                diagnostics = { globals = { "vim" } },
                workspace = { checkThirdParty = false },
                telemetry = { enable = false },
              },
            },
          })
        end
        if wants.java then
          add_one(configs, servers, "jdtls")
        end

        mlsp.setup({ ensure_installed = servers, automatic_installation = true })

        local function setup_server(server_name)
          pcall(function()
            local server = lspconfig[server_name]
            if server and server.setup then
              server.setup({ capabilities = caps })
            end
          end)
        end

        if type(mlsp.setup_handlers) == "function" then
          mlsp.setup_handlers({
            function(server_name)
              setup_server(server_name)
            end,
          })
        else
          for _, server_name in ipairs(servers) do
            setup_server(server_name)
          end
        end

        vim.keymap.set("n", "K", vim.lsp.buf.hover, { desc = "LSP Hover" })
        vim.keymap.set("n", "gd", vim.lsp.buf.definition, { desc = "LSP Definition" })
        vim.keymap.set("n", "gr", vim.lsp.buf.references, { desc = "LSP References" })
        vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename, { desc = "LSP Rename" })
      end,
    },
  }
end

return M
